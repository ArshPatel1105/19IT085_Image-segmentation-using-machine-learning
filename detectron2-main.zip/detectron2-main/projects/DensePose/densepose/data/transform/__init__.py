# Copyright (c) Facebook, Inc. and its affiliates.

from .image import ImageResizeTransform
